function [Vvec] = RC_volume_calcs(vent, pat)
% ARP 3/4/2020
% V3 17/4/2020
%
% Calculates lung volumes [Vmax, Vmin].  Tidal volume = Vmax - Vmin
% 
% vent, Structure of ventilator parameters
% pat,  Structure of patient parameters, including additional restrictors
%
% Units:
% Pressure cmH20
% Volume L
% Resistance cmH2O/(L/s)
% Compliance L/cmH2O

% Inspiration and expiration time constants (might end up the same, dependent
% on patient resistances and additional restrictors).  
Rvi = vent.R + pat.Rresti;  
Rve = vent.R + pat.Rreste;  
Ti = pat.Ri*pat.C + Rvi*(vent.C + pat.C);
Te = pat.Re*pat.C + Rve*(vent.C + pat.C);

% Vmax = a*Pi + Vmin*b  (1)
b = exp(-vent.Ts/Ti);
a = pat.C*(1-b);
% Vmin = c*Pe + Vmax*d  (2)
d = exp(-(vent.T-vent.Ts)/Te);
c = pat.C*(1-d);

% Dynamic stiffness matrix
K = [1/a  -b/a;  -d/c  1/c];

% Volume [Vmax; Vmin] vector
Vvec = K\[vent.Pi; vent.Pe];


