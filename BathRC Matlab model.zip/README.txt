The BathRC model: a method to estimate flow restrictor size for dual ventilation of dissimilar 
patients
Andrew R Plummer, Jonathan L du Bois, Siu Man Lee, Patrick Magee, Jens Roesner, Harinderjit S Gill

See preprint at:   https://www.medrxiv.org/content/10.1101/2020.04.12.20062497v1

Matlab/Simulink implementation:
Run   �RC_vent_params.m�  to set up parameters.
Run �RC_ventilation_model.slx� to simulate ventilation of two patients.

A R Plummer, University of Bath, UK
17th April 2020

