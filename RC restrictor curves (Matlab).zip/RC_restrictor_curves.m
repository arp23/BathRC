% BathRC model for Dual Patient Ventilation 
%
% Design curves to allow choice of ventilator settings and inspiration/expiration 
% restrictors for individual tidal volume and PEEP adjustment.
% Can be used to find parameters for simulation RC_ventilation_model.slx: UPDATE 
% PARAMETERS AT THE END OF THIS SCRIPT BY INSPECTING DESIGN CURVES
%
% ARP 20/4/2020
% V2 25/4/2020
%
% Each patient can be characterised by a series resistance (R) and
% compliance (C). R may be different for inspiration and expiration.
% Ventilator tubing system can also be approximated by lumped linear model,
% i.e resistance (Rv) and compliance (Cv). Inspiration and expiration restrictors 
% can be added in addition.
%
% When two patients are hooked up to the same ventilator, pressure control
% will be used, the ventilator stepping between low pressure (PEEP) and high
% pressure (PEEP+Pinsp).  This script calculates the full range of
% combinations of these pressures, and the inspiration and expiration time
% periods for given patient requirements.
% 
% Requirements specified for each patient:
% - tidal volume (Vmax-Vmin) delivered to each patient, 
% from minimum lung volume during expiration (Vmin), to maximum lung volume 
% during inspiration (Vmax). 
% - The minimum lung pressure(individual PEEP) 
%
% Units:
% Pressure cmH20
% Volume L
% Resistance cmH2O/(L/s)
% Compliance L/cmH2O

clear all;

%% ventilator parameters

vent.R       = 22;   % cmH2O/(L/s)  tubing resistance (inc. one way valves)
vent.C       = 0.004;% L/cmH2O   tubing/gas compliance

%% Patient 1 (Values provided match our test lung 1)
i = 1;                   
pat(i).Ri       = 12;      % cmH2O/(L/s) Inspiration airway resistance
pat(i).Re       = 12;      % cmH2O/(L/s) Expiration airway resistance
pat(i).C        = 0.040;   % L/cmH2O     Lung compliance
pat(i).Tvol     = 0.3;     % L           Required tidal volume
pat(i).Peep     = 8;       % cmH2O       Required end expiration lung pressure

%% Patient 2  (Values provided match our test lung 2)
i = 2;
pat(i).Ri       = 10;      % cmH2O/(L/s) Inspiration airway resistance*
pat(i).Re       = 10;      % cmH2O/(L/s) Expiration airway resistance*
pat(i).C        = 0.020;   % L/cmH2O     Lung compliance
pat(i).Tvol     = 0.3;     % L           Required tidal volume
pat(i).Peep     = 8;       % cmH2O       Required end expiration lung pressure
% *12 cmH2O/(L/s)in preprint which is an error (effect is small)

%% Conversion factors
cmH2O_to_Pa = 98.0665;
L_to_m3 = 1e-3;

%% Design curves

Pi = 15:40;                 % cmH2O  Range of insp pressures (Pinsp + vent PEEP), x axis 
dt_insp = 1:0.1:2.5;        % s      Range of inspiration time periods, y axis 
Pe = 0:0.5:10;              % cmH2O  Range of pressures for ventilator PEEP, x axis 
dt_exp = 1.5:0.1:3.5;       % s      Range of inspiration time periods, y axis 

for i=1:2                                   % For each patient
   
    pat(i).dp = pat(i).Tvol / pat(i).C;     % 'Tidal' lung pressure change  
  
    for x = 1:length(Pi)                    % For each inspiration pressure value
        for y = 1:length(dt_insp)           % For each inspiration time period
              normTi = -1/log( 1 - pat(i).dp/(Pi(x)-pat(i).Peep) );
              Ti = normTi * dt_insp(y);     % Inspiration time constant required
                                            % Inspiration restrictor required
              pat(i).Rresti(y,x) =(Ti - pat(i).Ri*pat(i).C) /(vent.C + pat(i).C) - vent.R;
        end
    end
    
    for x = 1:length(Pe)                    % For each expiration pressure value
        for y = 1:length(dt_exp)            % For each expiration time period
              d =  (pat(i).Peep  - Pe(x)) / (pat(i).Peep + pat(i).dp - Pe(x));
              normTe = -1/log( d );
              Te = normTe * dt_exp(y);     % Expiration time constant required
                                           % Expiration restrictor required
              pat(i).Rreste(y,x) =(Te - pat(i).Re*pat(i).C) /(vent.C + pat(i).C) - vent.R;
        end
    end
end

v = 0:10:200;                    % Restrictor contour values for plotting

figure(1); hold off;             % Inspiration plot
[C,h] = contour(Pi, dt_insp, real(pat(1).Rresti),v,'r-'); hold on; clabel(C,h);
[C,h] = contour(Pi, dt_insp, real(pat(2).Rresti),v,'k--');  clabel(C,h)
legend(sprintf('Patient 1: dp=%4.1f, PEEP=%4.1fcmH_2O', pat(1).dp, pat(1).Peep), ...
    sprintf('Patient 2: dp=%4.1f, PEEP=%4.1fcmH_2O', pat(2).dp, pat(2).Peep));
grid;
xlabel('Peak ventilator pressure (Pinsp + PEEP), cmH_20'); ylabel('Inspiration time, s');
title('Inspiration restrictor resistances, cmH_20/(L/s)');

figure(2); hold off;             % Expiration plot
[C,h] = contour(Pe, dt_exp, real(pat(1).Rreste),v,'r-'); hold on; clabel(C,h);
[C,h] = contour(Pe, dt_exp, real(pat(2).Rreste),v,'k--');  clabel(C,h)
legend(sprintf('Patient 1: dp=%4.1f, PEEP=%4.1fcmH_2O', pat(1).dp, pat(1).Peep), ...
    sprintf('Patient 2: dp=%4.1f, PEEP=%4.1fcmH_2O', pat(2).dp, pat(2).Peep));
grid;
xlabel('Ventilator PEEP setting, cmH_20'); ylabel('Expiration time, s');
title('Expiration restrictor resistances, cmH_20/(L/s)');

%% Choice of settings: SHOULD BE CHOSEN FROM DESIGN CURVES
%  Example entilator settings from design curves:
vent.Pi      = 25;   % Max ventilator pressure (Fig 1 x-axis)
vent.Pe      = 6;    % Min ventilator pressure (PEEP) (Fig 2 x-axis)
vent.Ts      = 1.5;  % s, inpsiration time period (Fig 1 y-axis)
Texp         = 2.25; % s, expiration time period (Fig 2 y-axis)
% Derived
vent.T       = vent.Ts + Texp;      % Period, s
resp_rate    = 1/vent.T*60;         % breaths/min
ins_to_ex    = vent.Ts/Texp;        % inspiration to expiration time ratio
PEEP         = vent.Pe;
Pinsp        = vent.Pi - PEEP;      % cmH20 (inspiration driving pressure is this + PEEP)
% Restrictors from design curves (patient 1 and 2 respectively)
pat(1).Rresti   = 27;       % cmH2O/(L/s) Resistance of additional inspiration restrictor (Fig 1)
pat(2).Rresti   = 0;        % cmH2O/(L/s) Resistance of additional inspiration restrictor (Fig 1)
pat(1).Rreste   = 0;        % cmH2O/(L/s) Resistance of additional expiration restrictor (Fig 2)
pat(2).Rreste   = 14;       % cmH2O/(L/s) Resistance of additional expiration restrictor (Fig 2)

%  Display ventilator settings and patient tidal volumes / PEEP.
fprintf('Current ventilator settings: RR=%4.1fbpm, I:E=%4.2f, Pinsp=%4.1fcmH_2O, PEEP=%4.1fcmH_2O \n',...
                            resp_rate, ins_to_ex, Pinsp, vent.Pe);
Vvec = RC_volume_calcs(vent, pat(1));   % Returns max and min lung volumes, Vvec(1) and Vvec(2).
fprintf('Patient 1: Tidal volume=%4.2fL, Individual PEEP=%4.1fcmH_2O \n', Vvec(1)-Vvec(2), Vvec(2)/pat(1).C);
pat(1).Vvec = Vvec;
Vvec = RC_volume_calcs(vent, pat(2));   % Returns max and min lung volumes, Vvec(1) and Vvec(2).
fprintf('Patient 2: Tidal volume=%4.2fL, Individual PEEP=%4.1fcmH_2O \n', Vvec(1)-Vvec(2), Vvec(2)/pat(2).C);
pat(2).Vvec = Vvec;

