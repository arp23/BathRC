% BathRC model: set up parameters for RC_ventilation_model.slx
% ARP 3/4/2020
% V3 17/4/2020
%
% A patient can be characterised by a series resistance (R) and compliance (C).
% Ventilator tubing system can also be approximated by lumped linear model,
% i.e resistance (Rv) and compliance (Cv).  Inspiration and expiration
% values are potential different.  Inspiration and expiration restrictors can be added
% in addition.
%
% When two patients are hooked up to the same ventilator, pressure control
% will be used, the ventilator stepping between low pressure (PEEP) and high
% pressure (PEEP+Pinsp).  The tidal volume (Vmax-Vmin) delivered to each patient, 
% from minimum lung volume during expiration (Vmin), to maximum lung volume 
% during inspiration (Vmax) is calculated and displayed
%
% Units:
% Pressure cmH20
% Volume L
% Resistance cmH2O/(L/s)
% Compliance L/cmH2O

clear all;

%% ventilator constants
Pinsp        = 25;   % cmH20 (inspiration driving pressure is this + PEEP)
resp_rate    = 15;   % breaths/min
ins_to_ex    = 1/2;  % inspiration to expiration time ratio
PEEP         = 5;    % cmH20 (= back pressure during expiration phase)
vent.R       = 22;   % cmH2O/(L/s) Based on JdB analysis of test data 1/4/2020
vent.C       = 0.004;% L/cmH2O  Approx, measured
% Derived
vent.T       = 60/resp_rate;              % Period, s
vent.Ts      = 1/(1/ins_to_ex+1)*vent.T;  % Switching time, s 
vent.Pi      = Pinsp+PEEP;                % Max ventilator pressure 
vent.Pe      = PEEP;                      % Min ventilator pressure

%% Patient 1 (Values provided match our test lung 1)
i = 1;                   
pat(i).Ri       = 12;      % cmH2O/(L/s) Inspiration airway resistance
pat(i).Re       = 12;      % cmH2O/(L/s) Expiration airway resistance
pat(i).C        = 0.040;   % L/cmH2O     Lung compliance
pat(i).Rresti   = 0;       % cmH2O/(L/s) Resistance of additional inspiration restrictor 
pat(i).Rreste   = 0;       % cmH2O/(L/s) Resistance of additional expiration restrictor 

% This function returns max and min lung volumes, Vvec(1) and Vvec(2) respectively.
pat(i).Vvec = RC_volume_calcs(vent, pat(i));
tidalvol(i) = pat(i).Vvec(1) - pat(i).Vvec(2);

%% Patient 2  (Values provided match our test lung 2)
i = 2;
pat(i).Ri       = 10;      % cmH2O/(L/s) Inspiration airway resistance*
pat(i).Re       = 10;      % cmH2O/(L/s) Expiration airway resistance*
pat(i).C        = 0.030;   % L/cmH2O     Lung compliance
pat(i).Rresti   = 0;       % cmH2O/(L/s) Resistance of additional inspiration restrictor 
pat(i).Rreste   = 0;       % cmH2O/(L/s) Resistance of additional expiration restrictor 
% *12 cmH2O/(L/s)in preprint which is an error (effect is small)

% This function returns max and min lung volumes, Vvec(1) and Vvec(2) respectively.
pat(i).Vvec = RC_volume_calcs(vent, pat(i));
tidalvol(i) = pat(i).Vvec(1) - pat(i).Vvec(2);

%% Other stuff

fprintf('Tidal volumes %5.3f L  %5.3f L\n', tidalvol(1), tidalvol(2));

% Conversion factors
cmH2O_to_Pa = 98.0665;
L_to_m3 = 1e-3;
